﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AK_WindowsFormsApp1
{
    public partial class AK_Form_Main : Form
    {

        Form F2 = new KM_Form2();

        public AK_Form_Main()
        {
            InitializeComponent();
        }

        private void AK_Form_Main_Load(object sender, EventArgs e)
        {

        }

        private void AK_button1_Click(object sender, EventArgs e)
        {
            Form F1 = new AK_Form1();
            F1.Visible = true;
            F1.Activate();
            // Vormi saab avada ainult yhe korra
            AK_button1.Enabled = false; 

        }

        private void KM_btn2_Click(object sender, EventArgs e)
        {
            if (F2.Visible==false)
            {
                F2 = new KM_Form2();
                F2.Visible = true;
                //Vormi saab avada ja sulgeda mitu kord, kuid ainult sama vormi
                F2.Activate();
            }
        }
    }
}
