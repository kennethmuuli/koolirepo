﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AK_WindowsFormsApp1
{

    //List<string> savedList { public get; private set };
    internal class km_ListClass
    {
        

        //public List<string> SaveList(List<string> eelmineList)
        //{
        //    List<string> unsortedList = new List<string>();



        //    if (km_check1.Checked == true)
        //    {
        //        for (int i = 0; i < km_list1.Items.Count; i++)
        //        {
        //            unsortedList.Insert(i, km_list1.Items[i].ToString());
        //        }

        //        km_list1.Sorted = true;
        //        km_check1.Text = "Sorted";
        //    }
        //    else
        //    {
        //        km_list1.Sorted = false;
        //        km_check1.Text = "Unsorted";
        //        km_list1.Items.Clear();

        //        for (int i = 0; i < unsortedList.Count; i++)
        //        {
        //            km_list1.Items.Insert(i, unsortedList[i]);
        //        }


        //    }
        //}

    }
}
