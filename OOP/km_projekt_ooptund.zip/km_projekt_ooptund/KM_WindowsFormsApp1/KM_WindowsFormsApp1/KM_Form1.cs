﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KM_WindowsFormsApp1
{
    public partial class KM_Form1 : Form
    {
        public KM_Form1()
        {
            InitializeComponent();
        }
    }
}
