﻿namespace KM_WindowsFormsApp1
{
    partial class KM_Form_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.KM_Frame1 = new System.Windows.Forms.GroupBox();
            this.KM_button1 = new System.Windows.Forms.Button();
            this.KM_Frame1.SuspendLayout();
            this.SuspendLayout();
            // 
            // KM_Frame1
            // 
            this.KM_Frame1.Controls.Add(this.KM_button1);
            this.KM_Frame1.Location = new System.Drawing.Point(35, 36);
            this.KM_Frame1.Name = "KM_Frame1";
            this.KM_Frame1.Size = new System.Drawing.Size(655, 443);
            this.KM_Frame1.TabIndex = 0;
            this.KM_Frame1.TabStop = false;
            // 
            // KM_button1
            // 
            this.KM_button1.Location = new System.Drawing.Point(58, 44);
            this.KM_button1.Name = "KM_button1";
            this.KM_button1.Size = new System.Drawing.Size(255, 73);
            this.KM_button1.TabIndex = 0;
            this.KM_button1.Text = "nupu nupu";
            this.KM_button1.UseVisualStyleBackColor = true;
            this.KM_button1.Click += new System.EventHandler(this.KM_button1_Click);
            // 
            // KM_Form_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 36F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(755, 526);
            this.Controls.Add(this.KM_Frame1);
            this.Font = new System.Drawing.Font("Courier New", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(186)));
            this.Margin = new System.Windows.Forms.Padding(10, 8, 10, 8);
            this.Name = "KM_Form_Main";
            this.Text = "KTA-22E";
            this.Load += new System.EventHandler(this.KM_Form_Main_Load);
            this.KM_Frame1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox KM_Frame1;
        private System.Windows.Forms.Button KM_button1;
    }
}

