tihedus=5.68/8
A=float(input("Milline on bensiinimahuti suurus (A) kuupmeetrites?"))
konvA=A*tihedus
B=float(input("Kui mitu tonni (B) bensiini soovite mahutis hoida?"))

if(konvA>=B):
    if(konvA==B):
        print("Bensiin mahub mahutisse ja täidab selle täpselt.")
    else:
        print("Bensiin mahub mahutisse.")
else:
    print("Bensiin ei mahu mahutisse.")
