vahemaa=1200

while(True):
     A=float(input("Peetri ja Antsu majade vahemaa on 1200 meetrit. Sisesta millise vahemaa on Peeter läbinud, kui ta jõuab nende kohtumispunkti A, et saada teada, kui mitu korda pikema või lühema tee pidi läbima Ants. A = "))
     if (A>0):
         break

B=vahemaa-A

if(A>=B):
    if(A==B):
        print("Peeter ja Ants läbisid sama pika vahemaa, täpselt ", str(A)," meetrit.")
    else:
        erisus=A/B
        print("Ants läbis ", str(erisus)," korda lühema tee, ehk ", str(B)," meetrit.")
else:
    erisus=B/A
    print("Ants läbis ", str(erisus)," korda pikema tee, ehk ", str(B)," meetrit.")
