esimene = 35
samm = 1
mitu = 53
jagaja = 7
jääk1 = 1
jääk2 = 2
jääk3 = 5

arv = esimene

print("Täisarvude jadas, mis ulatub 35-st 87-ni, annavad 7-ga jagamisel järgnevad arvud jäägiks (toodud välja sulgudes) üks, kaks või viis: ", end="")

for i in range(1, mitu+1, 1):
    tulem = arv%jagaja
    if (tulem==jääk1 or tulem==jääk2 or tulem==jääk3):
        if (i==2):
            print(str(arv) + "(" + str(tulem) + ")", end="")
        else:
            print(", " + str(arv) + "(" + str(tulem) + ")", end="")
    arv=arv+samm